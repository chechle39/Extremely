export const environment = {
  production: true,
  hmr: false,
  apiKey: 'XB-KEY',
  apiBaseUrl: 'http://localhost:3000/'
};
