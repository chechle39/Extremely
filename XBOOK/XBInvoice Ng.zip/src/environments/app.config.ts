export const API_URI = {
  invoice: 'api/v1/invoice',
  client: 'api/v1/client',
  product: 'api/v1/product',
  payment: 'api/v1/payment',
};
export const PAGING_CONFIG = {
  pageIndex: 1,
  pageSize: 10
};
