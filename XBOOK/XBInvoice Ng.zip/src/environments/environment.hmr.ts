export const environment = {
  production: false,
  hmr: true,
  apiKey: 'XB-KEY',
  apiBaseUrl: 'http://localhost:3000/'
};
