import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'xb-notification-sidebar',
  templateUrl: './notification-sidebar.component.html',
  styleUrls: ['./notification-sidebar.component.scss']
})
export class NotificationSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
