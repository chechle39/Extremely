export class InvoiceSearch {
  seachString: string;
  form: string;
  to: string;
}
