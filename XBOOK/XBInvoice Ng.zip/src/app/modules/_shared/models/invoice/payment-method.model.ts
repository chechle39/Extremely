export class PaymentMethod {
  constructor(public payTypeId: number, public payType: string) {
  }
}
