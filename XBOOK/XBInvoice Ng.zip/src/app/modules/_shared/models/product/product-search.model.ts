export class ProductSearchModel {
  public id: number;
  public productName: string;
  public unitPrice: number;
}
