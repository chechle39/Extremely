export class ProductCategory {
  constructor(public id: number, public Name: string) {
  }
}
