export class BaseModel {
  id: number;
  version: number;
}
